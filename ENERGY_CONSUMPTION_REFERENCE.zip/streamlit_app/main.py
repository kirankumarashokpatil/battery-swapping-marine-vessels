from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import pandas as pd
import streamlit as st

ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from fixed_path_dp import (
    FixedPathInputs,
    FixedPathOptimizer,
    Segment,
    SegmentOption,
    Station,
)


@st.cache_data
def load_default_config() -> Dict:
    import random
    
    # Generate randomized distances (25-55 NM range)
    distances = {}
    route_segments = ["A-B", "B-C", "C-D", "D-E", "E-F", "F-G", "G-H", "H-I", "I-J", "J-K", "K-L", "L-M", "M-N", "N-O", "O-P", "P-Q", "Q-R", "R-S", "S-T"]
    
    # Keep first few segments as provided in your data
    distances.update({
        "A-B": 40.0,
        "B-C": 35.0,
        "C-D": 45.0,
        "D-E": 30.0,
    })
    
    # Randomize remaining segments
    for segment in route_segments[4:]:  # Skip first 4
        distances[segment] = round(random.uniform(25.0, 55.0), 1)
    
    # Generate randomized currents (-3.0 to +3.5 knots range)
    currents = {}
    currents.update({
        "A-B": -2.5,  # Upstream (against flow)
        "B-C": -1.8,  # Upstream (against flow)
        "C-D": 3.2,   # Downstream (with flow)
        "D-E": 2.0,   # Downstream (with flow)
    })
    
    # Randomize remaining currents
    for segment in route_segments[4:]:  # Skip first 4
        currents[segment] = round(random.uniform(-3.0, 3.5), 1)
    
    # Generate randomized station configs
    stations = {
        "A": {
            "swap_cost": 0.0,
            "swap_time_hr": 0.0,
            "queue_time_hr": 0.0,
            "allow_swap": False,
        },
        "B": {
            "swap_cost": 235.0,
            "swap_time_hr": 0.75,
            "queue_time_hr": 0.25,
            "operating_hours": [6.0, 22.0],
            "available_batteries": 5,
            "energy_cost_per_kwh": 0.09,
        },
        "C": {
            "swap_cost": 250.0,
            "swap_time_hr": 0.75,
            "queue_time_hr": 0.5,
            "operating_hours": [0.0, 24.0],
            "available_batteries": 4,
            "energy_cost_per_kwh": 0.18,
        },
        "D": {
            "swap_cost": 220.0,
            "swap_time_hr": 0.75,
            "queue_time_hr": 0.17,
            "operating_hours": [8.0, 20.0],
            "available_batteries": 12,
            "energy_cost_per_kwh": 0.09,
        },
        "E": {
            "swap_cost": 0.0,
            "swap_time_hr": 0.0,
            "queue_time_hr": 0.0,
            "allow_swap": False,
        },
    }
    
    # Generate random station configs for F-S (T is destination)
    station_names = ["F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S"]
    for station in station_names:
        if station in ["K", "P"]:  # Make some stations non-swap for variety
            stations[station] = {
                "swap_cost": 0.0,
                "swap_time_hr": 0.0,
                "queue_time_hr": 0.0,
                "allow_swap": False,
            }
        else:
            # Some stations are 24/7, others have limited hours
            is_24_7 = random.random() > 0.75
            stations[station] = {
                "swap_cost": round(random.uniform(180.0, 320.0), 0),
                "swap_time_hr": round(random.uniform(0.4, 1.2), 2),
                "queue_time_hr": round(random.uniform(0.1, 0.9), 2),
                "operating_hours": [0.0, 24.0] if is_24_7 else [random.randint(5, 9), random.randint(16, 23)],
                "available_batteries": random.randint(3, 12),
                "energy_cost_per_kwh": round(random.uniform(0.07, 0.22), 3),
            }
    
    # T is always destination (no swap)
    stations["T"] = {
        "swap_cost": 0.0,
        "swap_time_hr": 0.0,
        "queue_time_hr": 0.0,
        "allow_swap": False,
    }
    
    return {
        "route": ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T"],
        "distances_nm": distances,
        "currents_knots": currents,
        "boat_speed_knots": 5.0,  # 5 knots - typical for cargo vessels
        "base_consumption_per_nm": 220.0,  # Based on actual data: 207-245 kWh/NM for laden cargo vessels
        "battery_capacity_kwh": 19600.0,  # 10 containers × 1960 kWh = 19.6 MWh total
        "battery_container_capacity_kwh": 1960.0,  # Standard 20-foot ISO container capacity
        "initial_soc_kwh": 19600.0,  # Start with full battery (100%)
        "minimum_soc_fraction": 0.2,  # Industry standard 20% reserve
        "energy_cost_per_kwh": 0.12,
        "time_cost_per_hr": 25.0,
        "soc_step_kwh": 20.0,  # Adjusted for containerized battery capacity (1960 kWh)
        "start_time_hr": 6.0,
        "stations": stations,
    }


def calculate_energy_consumption(
    distance_nm: float,
    current_knots: float,
    boat_speed_knots: float,
    base_consumption_per_nm: float,
) -> float:
    base_energy = distance_nm * base_consumption_per_nm
    multiplier = 1.2 if current_knots < 0 else 0.8
    return base_energy * multiplier


def build_segment_option(
    segment_name: str,
    distance_nm: float,
    current_knots: float,
    boat_speed_knots: float,
    base_consumption_per_nm: float,
) -> SegmentOption:
    ground_speed = boat_speed_knots + current_knots
    if ground_speed <= 0:
        raise ValueError(f"Ground speed becomes non-positive for segment {segment_name}.")
    travel_time_hr = distance_nm / ground_speed
    energy_kwh = calculate_energy_consumption(
        distance_nm,
        current_knots,
        boat_speed_knots,
        base_consumption_per_nm,
    )
    return SegmentOption(
        label=segment_name,
        travel_time_hr=travel_time_hr,
        energy_kwh=energy_kwh,
    )


def _safe_float(value: object, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        if isinstance(value, str) and not value.strip():
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _safe_bool(value: object, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if not text:
        return default
    return text in {"true", "1", "yes", "y"}


def _safe_int(value: object) -> int | None:
    if value is None:
        return None
    if isinstance(value, str) and not value.strip():
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _pairwise(iterable: Iterable[str]) -> Iterable[Tuple[str, str]]:
    iterator = iter(iterable)
    prev = next(iterator, None)
    for current in iterator:
        if prev is None:
            break
        yield prev, current
        prev = current


def build_inputs(config: Dict) -> FixedPathInputs:
    route = config["route"]
    distances = config["distances_nm"]
    currents = config["currents_knots"]
    boat_speed = float(config["boat_speed_knots"])
    base_consumption = float(config["base_consumption_per_nm"])

    segments: List[Segment] = []
    for start, end in _pairwise(route):
        key = f"{start}-{end}"
        if key not in distances or key not in currents:
            raise ValueError(f"Missing data for segment {key}")
        option = build_segment_option(
            segment_name=f"{start}->{end}",
            distance_nm=float(distances[key]),
            current_knots=float(currents[key]),
            boat_speed_knots=boat_speed,
            base_consumption_per_nm=base_consumption,
        )
        segments.append(Segment(start=start, end=end, options=[option]))

    stations: List[Station] = []
    for name in route:
        station_cfg = config.get("stations", {}).get(name, {})
        operating = station_cfg.get("operating_hours")
        operating_tuple = None
        if operating:
            if len(operating) != 2:
                raise ValueError(f"Station {name} operating_hours must have two values")
            operating_tuple = (float(operating[0]), float(operating[1]))
        
        # Peak hours for dynamic pricing
        peak_hours_cfg = station_cfg.get("peak_hours")
        peak_hours_tuple = None
        if peak_hours_cfg:
            if len(peak_hours_cfg) != 2:
                raise ValueError(f"Station {name} peak_hours must have two values")
            peak_hours_tuple = (float(peak_hours_cfg[0]), float(peak_hours_cfg[1]))
        
        stations.append(
            Station(
                name=name,
                swap_cost=float(station_cfg.get("swap_cost", 0.0)),
                swap_time_hr=float(station_cfg.get("swap_time_hr", 0.0)),
                queue_time_hr=float(station_cfg.get("queue_time_hr", 0.0)),
                operating_hours=operating_tuple,
                available_batteries=_safe_int(station_cfg.get("available_batteries")),
                allow_swap=_safe_bool(station_cfg.get("allow_swap", True), default=True),
                force_swap=_safe_bool(station_cfg.get("force_swap", False), default=False),
                partial_swap_allowed=_safe_bool(station_cfg.get("partial_swap_allowed", False), default=False),
                energy_cost_per_kwh=float(station_cfg.get("energy_cost_per_kwh", 0.09)),
                # Hybrid pricing components
                base_service_fee=float(station_cfg.get("base_service_fee", 0.0)),
                location_premium=float(station_cfg.get("location_premium", 0.0)),
                degradation_fee_per_kwh=float(station_cfg.get("degradation_fee_per_kwh", 0.0)),
                peak_hour_multiplier=float(station_cfg.get("peak_hour_multiplier", 1.0)),
                peak_hours=peak_hours_tuple,
                subscription_discount=float(station_cfg.get("subscription_discount", 0.0)),
            )
        )

    battery_capacity = float(config["battery_capacity_kwh"])
    battery_container_capacity = float(config.get("battery_container_capacity_kwh", 1960.0))  # Default to standard container
    initial_soc = float(config.get("initial_soc_kwh", battery_capacity))
    min_soc_fraction = float(config.get("minimum_soc_fraction", 0.0))
    min_soc = battery_capacity * min_soc_fraction
    final_soc_value = config.get("final_soc_min_kwh")
    if final_soc_value is not None:
        final_soc_min = float(final_soc_value)
    else:
        final_fraction = config.get("final_soc_fraction")
        final_soc_min = (
            battery_capacity * float(final_fraction)
            if final_fraction is not None
            else min_soc
        )

    return FixedPathInputs(
        stations=stations,
        segments=segments,
        battery_capacity_kwh=battery_capacity,
        battery_container_capacity_kwh=battery_container_capacity,
        initial_soc_kwh=initial_soc,
        final_soc_min_kwh=final_soc_min,
        min_soc_kwh=min_soc,
        energy_cost_per_kwh=float(config["energy_cost_per_kwh"]),
        time_cost_per_hr=float(config["time_cost_per_hr"]),
        soc_step_kwh=float(config["soc_step_kwh"]),
        start_time_hr=float(config["start_time_hr"]),
    )


def config_to_form_frames(config: Dict) -> Tuple[pd.DataFrame, pd.DataFrame]:
    route = config["route"]
    segment_rows: List[Dict[str, object]] = []
    for start, end in _pairwise(route):
        key = f"{start}-{end}"
        current_value = config["currents_knots"].get(key, 0.0)
        
        # Convert to absolute value and direction
        flow_speed = abs(current_value)
        direction = "Upstream" if current_value < 0 else "Downstream"
        
        segment_rows.append(
            {
                "Start": start,
                "End": end,
                "Distance (NM)": config["distances_nm"].get(key, 0.0),
                "Flow Speed (knots)": flow_speed,
                "Direction": direction,
            }
        )
    segments_df = pd.DataFrame(segment_rows)

    station_rows: List[Dict[str, object]] = []
    for name in route:
        station_cfg = config.get("stations", {}).get(name, {})
        operating = station_cfg.get("operating_hours")
        station_rows.append(
            {
                "Station": name,
                "Allow Swap": station_cfg.get("allow_swap", True),
                "Force Swap": station_cfg.get("force_swap", False),
                "Swap Cost": station_cfg.get("swap_cost", 0.0),
                "Swap Time (hr)": station_cfg.get("swap_time_hr", 0.0),
                "Queue Time (hr)": station_cfg.get("queue_time_hr", 0.0),
                "Open Hour": operating[0] if operating else 0.0,
                "Close Hour": operating[1] if operating else 24.0,
                "Available Batteries": station_cfg.get("available_batteries", pd.NA),
                "Energy Cost ($/kWh)": station_cfg.get("energy_cost_per_kwh", 0.09),
            }
        )
    stations_df = pd.DataFrame(station_rows)
    if not stations_df.empty:
        stations_df["Available Batteries"] = stations_df["Available Batteries"].astype("Int64")
    return segments_df, stations_df


def form_frames_to_config(
    route_text: str,
    segments_df: pd.DataFrame,
    stations_df: pd.DataFrame,  # <-- Receives the station data now
    params: Dict[str, float],
) -> Dict:
    stops = [stop.strip() for stop in route_text.split(",") if stop.strip()]
    if len(stops) < 2:
        raise ValueError("Route must contain at least two stops")

    segment_records = segments_df.to_dict(orient="records")
    if len(segment_records) != len(stops) - 1:
        raise ValueError("Number of segment rows must equal number of route legs")

    distances: Dict[str, float] = {}
    currents: Dict[str, float] = {}
    for row, (start, end) in zip(segment_records, _pairwise(stops)):
        key = f"{start}-{end}"
        distances[key] = _safe_float(row.get("Distance (NM)"))
        
        flow_speed = _safe_float(row.get("Flow Speed (knots)"), 0.0)
        direction = row.get("Direction", "Downstream")
        currents[key] = -flow_speed if direction == "Upstream" else flow_speed

    station_cfg: Dict[str, Dict[str, object]] = {}
    
    # --- THIS IS THE NEW, CORRECTED LOGIC ---
    # Read the station records from the stations_df DataFrame
    station_records = stations_df.to_dict(orient="records")
    for record in station_records:
        name = record.get("Station")
        if not name:
            continue
            
        open_hour = _safe_float(record.get("Open Hour"), 0.0)
        close_hour = _safe_float(record.get("Close Hour"), 24.0)
        
        # Check if peak pricing is enabled
        enable_peak = _safe_bool(record.get("Enable Peak"), default=False)
        peak_hours_list = None
        if enable_peak:
            peak_start = _safe_float(record.get("Peak Start"), 8.0)
            peak_end = _safe_float(record.get("Peak End"), 18.0)
            peak_hours_list = [peak_start, peak_end]
            
        cfg: Dict[str, object] = {
            "allow_swap": _safe_bool(record.get("Allow Swap"), default=True),
            "force_swap": _safe_bool(record.get("Force Swap"), default=False),
            "partial_swap_allowed": _safe_bool(record.get("Partial Swap"), default=False),
            "swap_cost": _safe_float(record.get("Swap Cost")),
            "swap_time_hr": _safe_float(record.get("Swap Time (hr)")),
            "queue_time_hr": _safe_float(record.get("Queue Time (hr)")),
            "operating_hours": [open_hour, close_hour],
            "energy_cost_per_kwh": _safe_float(record.get("Energy Cost ($/kWh)"), 0.09),
            
            # Read all hybrid pricing components from the form
            "base_service_fee": _safe_float(record.get("Base Service Fee"), 0.0),
            "location_premium": _safe_float(record.get("Location Premium"), 0.0),
            "degradation_fee_per_kwh": _safe_float(record.get("Degradation Fee"), 0.0),
            "subscription_discount": _safe_float(record.get("Subscription Discount"), 0.0),
            "peak_hour_multiplier": _safe_float(record.get("Peak Multiplier"), 1.0),
        }
        
        if peak_hours_list is not None:
            cfg["peak_hours"] = peak_hours_list
        
        available = record.get("Available Batteries")
        # Handle the 999 placeholder for 'unlimited'
        if available == 999:
             cfg["available_batteries"] = None
        else:
            available_int = _safe_int(available)
            if available_int is not None:
                cfg["available_batteries"] = available_int
                
        station_cfg[name] = cfg

    for stop in stops:
        station_cfg.setdefault(stop, {})

    config = {
        "route": stops,
        "distances_nm": distances,
        "currents_knots": currents,
        "boat_speed_knots": params["boat_speed"],
        "base_consumption_per_nm": params["base_consumption"],
        "battery_capacity_kwh": params["battery_capacity"],
        "battery_container_capacity_kwh": params.get("battery_container_capacity", 1960.0),
        "initial_soc_kwh": params.get("initial_soc_kwh", params["battery_capacity"]),
        "minimum_soc_fraction": params["minimum_soc"],
        "energy_cost_per_kwh": 0.09,  # Default fallback (actual costs are per-station) - Guangzhou/Zhao Qing pricing
        "time_cost_per_hr": params["time_cost"],
        "soc_step_kwh": params["soc_step"],
        "start_time_hr": params["start_time"],
        "stations": station_cfg,
    }
    return config


def run_optimizer(config: Dict) -> Tuple[pd.DataFrame, Dict[str, object]]:
    inputs = build_inputs(config)
    optimizer = FixedPathOptimizer(inputs)
    result = optimizer.solve()

    steps_rows: List[Dict[str, object]] = []
    soc_profile: List[Tuple[str, float]] = []
    for step in result.steps:
        dwell_time = step.station_wait_time_hr + step.station_queue_time_hr + step.station_swap_time_hr
        
        # Get flow direction for this segment
        segment_key = step.segment_label.replace('->', '-')
        current = config.get('currents_knots', {}).get(segment_key, 0)
        flow_direction = "⬆️ Upstream" if current < 0 else "⬇️ Downstream"
        
        steps_rows.append(
            {
                "Station": step.station_name,
                "Segment": step.segment_label,
                "Flow": flow_direction,
                "Swap": step.swap_taken,
                "Containers": step.num_containers_swapped,  # Add number of containers
                "Arrival (hr)": step.arrival_time_hr,
                "Departure (hr)": step.departure_time_hr,
                "Dwell (hr)": dwell_time,
                "Travel (hr)": step.travel_time_hr,
                "SoC Before (kWh)": step.soc_before_kwh,
                "SoC After Segment (kWh)": step.soc_after_segment_kwh,
                "Incremental Cost": step.incremental_cost,
                "Cumulative Cost": step.cumulative_cost,
            }
        )
        soc_profile.append((step.station_name, step.soc_before_kwh))
    if result.steps:
        terminal_segment = result.steps[-1].segment_label
        terminal_stop = terminal_segment.split("->")[-1]
        soc_profile.append((terminal_stop, result.steps[-1].soc_after_segment_kwh))

    totals = {
        "total_cost": result.total_cost,
        "total_time": result.total_time_hr,
        "finish_time": result.finish_time_hr,
        "soc_profile": soc_profile,
    }

    steps_df = pd.DataFrame(steps_rows)
    return steps_df, totals


def render_results(steps_df: pd.DataFrame, totals: Dict[str, object], config: Dict) -> None:
    st.success("✅ Optimisation Complete!")
    st.markdown("---")

    # --- CALCULATE TRUE COST BREAKDOWN ONCE ---
    # This matches the optimizer's actual hybrid pricing model
    total_swap_service_cost = 0.0
    total_energy_charging_cost = 0.0
    total_base_fees = 0.0
    total_location_premium = 0.0
    total_degradation = 0.0
    total_peak_surcharge = 0.0
    total_discount = 0.0
    battery_cap = config.get('battery_capacity_kwh', 1960.0)
    
    swap_cost_details = []  # Store individual swap costs for table
    
    if not steps_df.empty:
        for idx, row in steps_df.iterrows():
            if row['Swap']:
                station_name = row['Station']
                station_config = config.get('stations', {}).get(station_name, {})
                soc_before_swap = row['SoC Before (kWh)']
                num_containers = row.get('Containers', 1)
                arrival_time = row['Arrival (hr)']
                
                # Calculate ACTUAL energy charged (SoC-based billing)
                energy_needed = battery_cap - soc_before_swap
                
                # Get all hybrid pricing components
                swap_service = station_config.get('swap_cost', 0) * num_containers
                energy_charging = energy_needed * station_config.get('energy_cost_per_kwh', 0.09)
                base_fee = station_config.get('base_service_fee', 0.0)
                location_premium = station_config.get('location_premium', 0.0) * num_containers
                degradation_fee = station_config.get('degradation_fee_per_kwh', 0.0) * energy_needed
                
                # Peak pricing logic
                peak_hours = station_config.get('peak_hours')
                peak_multiplier = station_config.get('peak_hour_multiplier', 1.0)
                is_peak = False
                if peak_hours:
                    peak_start, peak_end = peak_hours
                    is_peak = peak_start <= (arrival_time % 24) < peak_end
                
                # Subscription discount
                subscription_discount = station_config.get('subscription_discount', 0.0)
                
                # Calculate subtotal before peak/discount
                subtotal_before_adjustments = swap_service + energy_charging + base_fee + location_premium + degradation_fee
                
                # Apply peak multiplier
                if is_peak and peak_multiplier > 1.0:
                    peak_surcharge = subtotal_before_adjustments * (peak_multiplier - 1.0)
                    subtotal_after_peak = subtotal_before_adjustments * peak_multiplier
                else:
                    peak_surcharge = 0.0
                    subtotal_after_peak = subtotal_before_adjustments
                
                # Apply subscription discount
                discount_amount = subtotal_after_peak * subscription_discount
                total_cost_this_swap = subtotal_after_peak - discount_amount
                
                # Accumulate totals
                total_swap_service_cost += swap_service
                total_energy_charging_cost += energy_charging
                total_base_fees += base_fee
                total_location_premium += location_premium
                total_degradation += degradation_fee
                total_peak_surcharge += peak_surcharge
                total_discount += discount_amount
                
                # Store details for table
                swap_cost_details.append({
                    'station_name': station_name,
                    'num_containers': num_containers,
                    'soc_before': soc_before_swap,
                    'energy_needed': energy_needed,
                    'swap_service': swap_service,
                    'energy_charging': energy_charging,
                    'base_fee': base_fee,
                    'location_premium': location_premium,
                    'degradation_fee': degradation_fee,
                    'peak_surcharge': peak_surcharge,
                    'discount_amount': discount_amount,
                    'total_cost': total_cost_this_swap,
                    'is_peak': is_peak,
                    'energy_rate': station_config.get('energy_cost_per_kwh', 0.09),
                    'swap_time': station_config.get('swap_time_hr', 0),
                    'partial_swap_allowed': station_config.get('partial_swap_allowed', False),
                })
    
    # Total of all swap-related costs
    total_all_swap_costs = (
        total_swap_service_cost + 
        total_energy_charging_cost + 
        total_base_fees + 
        total_location_premium + 
        total_degradation +
        total_peak_surcharge -
        total_discount
    )
    
    # Time cost and other non-swap costs
    total_time_and_other_costs = totals['total_cost'] - total_all_swap_costs
    # --- END COST BREAKDOWN ---

    # Key Metrics Row
    st.markdown("### 📊 Journey Summary")
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric(
            "💰 Total Cost", 
            f"${totals['total_cost']:,.2f}",
            help="Total cost including energy, time, and swap costs"
        )
    with col2:
        st.metric(
            "⏱️ Travel Time", 
            f"{totals['total_time']:.2f} hrs",
            help="Total journey time including swaps and waiting"
        )
    with col3:
        st.metric(
            "🕐 Arrival Time", 
            f"{totals['finish_time']:.2f} hrs",
            help="Clock time when journey completes"
        )
    with col4:
        swaps_count = len(swap_cost_details)
        st.metric(
            "🔋 Battery Swaps", 
            swaps_count,
            help="Total number of battery swaps"
        )

    st.markdown("---")

    if not steps_df.empty:
        # Enhanced summary with swap breakdown
        st.markdown("### � Battery Swap Summary")
        if swap_cost_details:
            swap_col1, swap_col2, swap_col3, swap_col4 = st.columns(4)
            
            with swap_col1:
                st.metric(
                    "🔄 Total Swaps",
                    len(swap_cost_details),
                    help="Number of battery swaps during journey"
                )
            
            with swap_col2:
                st.metric(
                    "💵 Swap Costs",
                    f"${total_all_swap_costs:.2f}",
                    help="Total of all swap-related costs (service + energy + fees + surcharges - discounts)"
                )
            
            with swap_col3:
                st.metric(
                    "⏱️ Time Cost",
                    f"${total_time_and_other_costs:.2f}",
                    help="Cost of journey time (from time_cost_per_hr)"
                )
            
            with swap_col4:
                avg_swap_cost = total_all_swap_costs / len(swap_cost_details) if swap_cost_details else 0
                st.metric(
                    "📊 Avg Swap Cost",
                    f"${avg_swap_cost:.2f}",
                    help="Average total cost per swap including all fees"
                )
            
            # Detailed swap table with COMPLETE cost breakdown
            st.markdown("#### 📍 Swap Locations & Details")
            swap_table_data = []
            total_containers_swapped = 0
            
            for detail in swap_cost_details:
                total_containers_swapped += detail['num_containers']
                
                # Determine swap mode
                total_num_containers = int(battery_cap / config.get('battery_container_capacity_kwh', 1960))
                swap_mode = "🔄 Partial" if (detail['partial_swap_allowed'] and detail['num_containers'] < total_num_containers) else "📦 Full Set"
                
                soc_before_pct = (detail['soc_before'] / battery_cap) * 100
                peak_indicator = " 🔺" if detail['is_peak'] else ""
                
                swap_table_data.append({
                    'Station': detail['station_name'] + peak_indicator,
                    'Mode': swap_mode,
                    'Containers': detail['num_containers'],
                    'Returned SoC': f"{detail['soc_before']:.0f} kWh ({soc_before_pct:.0f}%)",
                    'Energy Charged': f"{detail['energy_needed']:.0f} kWh",
                    'Service Fee': f"${detail['swap_service']:.2f}",
                    'Energy Cost': f"${detail['energy_charging']:.2f}",
                    'Base Fee': f"${detail['base_fee']:.2f}",
                    'Location': f"${detail['location_premium']:.2f}",
                    'Degradation': f"${detail['degradation_fee']:.2f}",
                    'Peak Surge': f"${detail['peak_surcharge']:.2f}" if detail['peak_surcharge'] > 0 else "—",
                    'Discount': f"-${detail['discount_amount']:.2f}" if detail['discount_amount'] > 0 else "—",
                    'Total Cost': f"${detail['total_cost']:.2f}",
                    'Swap Time': f"{detail['swap_time']:.2f} hr",
                })
            
            if swap_table_data:
                swap_df = pd.DataFrame(swap_table_data)
                
                st.info(f"""
                📦 **Total Battery Containers Swapped**: {total_containers_swapped} BC across {len(swap_cost_details)} station(s)
                
                💡 **Hybrid Pricing Model**: Costs include service fees, energy (SoC-based billing), base fees, location premiums, degradation fees, peak surcharges, and subscription discounts.
                
                🔺 **Peak Hours**: Stations with this indicator applied surge pricing.
                """)
                
                st.dataframe(
                    swap_df,
                    use_container_width=True,
                    hide_index=True
                )
        else:
            st.info("✨ **No battery swaps needed!** The journey can be completed on a single charge.")
        
        st.markdown("---")
        
        # Two-column layout for details and chart
        col_left, col_right = st.columns([3, 2])
        
        with col_left:
            st.markdown("### 🛤️ Detailed Journey Plan")
            
            # Format the dataframe for better readability
            display_df = steps_df.copy()
            display_df['Swap'] = display_df['Swap'].apply(lambda x: '✅' if x else '—')
            
            st.dataframe(
                display_df,
                width='stretch',
                column_config={
                    "Station": st.column_config.TextColumn("Station", width="small"),
                    "Segment": st.column_config.TextColumn("Segment", width="medium"),
                    "Flow": st.column_config.TextColumn("Flow", width="small"),
                    "Swap": st.column_config.TextColumn("Swap?", width="small"),
                    "Arrival (hr)": st.column_config.NumberColumn("Arrival", format="%.2f hr"),
                    "Departure (hr)": st.column_config.NumberColumn("Departure", format="%.2f hr"),
                    "Dwell (hr)": st.column_config.NumberColumn("Dwell", format="%.2f hr"),
                    "Travel (hr)": st.column_config.NumberColumn("Travel", format="%.2f hr"),
                    "SoC Before (kWh)": st.column_config.NumberColumn("SoC Before", format="%.1f kWh"),
                    "SoC After Segment (kWh)": st.column_config.NumberColumn("SoC After", format="%.1f kWh"),
                    "Incremental Cost": st.column_config.NumberColumn("Step Cost", format="$%.2f"),
                    "Cumulative Cost": st.column_config.NumberColumn("Total Cost", format="$%.2f"),
                },
                hide_index=True
            )
        
        with col_right:
            st.markdown("### 📈 State of Charge Profile")
            soc_df = pd.DataFrame(totals["soc_profile"], columns=["Stop", "SoC (kWh)"])
            st.line_chart(soc_df.set_index("Stop"), height=400)
            
            st.markdown("### 💡 Quick Insights")
            avg_soc = soc_df["SoC (kWh)"].mean()
            min_soc = soc_df["SoC (kWh)"].min()
            max_soc = soc_df["SoC (kWh)"].max()
            
            st.info(f"""
            - **Average SoC**: {avg_soc:.1f} kWh
            - **Minimum SoC**: {min_soc:.1f} kWh
            - **Maximum SoC**: {max_soc:.1f} kWh
            """)
        
        st.markdown("---")
        
        # Visualization Section
        st.markdown("### 📊 Decision Analysis Visualizations")
        
        viz_tab1, viz_tab2, viz_tab3, viz_tab4 = st.tabs([
            "🔋 Energy Balance", 
            "💰 Cost Breakdown", 
            "📊 Segment Analysis",
            "🔄 Swap Decisions"
        ])
        
        with viz_tab1:
            st.markdown("#### Energy Balance Per Segment")
            
            # Build energy balance data
            energy_data = []
            cumulative_energy = 0
            battery_cap = config['battery_capacity_kwh']
            min_soc_kwh = battery_cap * config.get('minimum_soc_fraction', 0.2)
            
            for idx, row in steps_df.iterrows():
                segment = row['Segment']
                soc_before = row['SoC Before (kWh)']
                soc_after = row['SoC After Segment (kWh)']
                energy_consumed = soc_before - soc_after
                
                # Check if swap happened
                if row['Swap']:
                    soc_before = battery_cap  # After swap
                    energy_consumed = battery_cap - soc_after
                
                cumulative_energy += energy_consumed
                
                energy_data.append({
                    'Segment': segment,
                    'Energy Consumed (kWh)': energy_consumed,
                    'SoC Before (kWh)': soc_before,
                    'SoC After (kWh)': soc_after,
                    'Cumulative Energy (kWh)': cumulative_energy,
                    'Swapped': '✅' if row['Swap'] else '—'
                })
            
            energy_df = pd.DataFrame(energy_data)
            
            # Bar chart: Energy consumed per segment
            st.markdown("**Energy Consumption by Segment**")
            chart_data = energy_df[['Segment', 'Energy Consumed (kWh)']].set_index('Segment')
            st.bar_chart(chart_data, height=300)
            
            # Show table with details
            st.dataframe(
                energy_df,
                width='stretch',
                column_config={
                    "Segment": st.column_config.TextColumn("Segment", width="medium"),
                    "Energy Consumed (kWh)": st.column_config.NumberColumn("Energy Used", format="%.1f kWh"),
                    "SoC Before (kWh)": st.column_config.NumberColumn("SoC Before", format="%.1f kWh"),
                    "SoC After (kWh)": st.column_config.NumberColumn("SoC After", format="%.1f kWh"),
                    "Cumulative Energy (kWh)": st.column_config.NumberColumn("Cumulative", format="%.1f kWh"),
                    "Swapped": st.column_config.TextColumn("Swap", width="small"),
                },
                hide_index=True
            )
            
            # Explanation
            st.info(f"""
            **📌 Energy Analysis:**
            - Battery Capacity: {battery_cap:.1f} kWh
            - Minimum SoC Threshold: {min_soc_kwh:.1f} kWh
            - Total Energy Consumed: {cumulative_energy:.1f} kWh
            - Segments with Swaps: {energy_df['Swapped'].str.contains('✅').sum()}
            
            **Why Swaps Were Needed:**
            If SoC After falls below {min_soc_kwh:.1f} kWh or segment energy exceeds remaining capacity, a swap is required.
            """)
        
        with viz_tab2:
            st.markdown("#### Cost Structure Analysis")
            
            # Extract cost components with ACTUAL energy charged
            cost_breakdown = []
            total_swap_service_cost = 0
            total_energy_charging_cost = 0
            total_base_fees = 0
            total_location_premium = 0
            total_degradation = 0
            
            for idx, row in steps_df.iterrows():
                if row['Swap']:
                    station_name = row['Station']
                    station_config = config.get('stations', {}).get(station_name, {})
                    
                    # Get actual energy needed (not full battery!)
                    soc_before_swap = row['SoC Before (kWh)']
                    energy_needed = battery_cap - soc_before_swap  # Only charge what's missing
                    
                    # Get number of containers swapped
                    num_containers = row.get('Containers', 10)
                    
                    # Calculate cost components
                    swap_service = station_config.get('swap_cost', 0) * num_containers
                    energy_cost_per_kwh = station_config.get('energy_cost_per_kwh', 0.09)
                    energy_charging = energy_needed * energy_cost_per_kwh
                    
                    # Hybrid pricing components
                    base_fee = station_config.get('base_service_fee', 0.0)
                    location_premium = station_config.get('location_premium', 0.0) * num_containers
                    degradation_fee = station_config.get('degradation_fee_per_kwh', 0.0) * energy_needed
                    
                    total_swap_service_cost += swap_service
                    total_energy_charging_cost += energy_charging
                    total_base_fees += base_fee
                    total_location_premium += location_premium
                    total_degradation += degradation_fee
                    
                    # Build cost breakdown with only relevant columns
                    swap_row = {
                        'Station': station_name,
                        'Containers': num_containers,
                        'Energy Charged (kWh)': f"{energy_needed:.0f}",
                        'Service Fee': f"${swap_service:.2f}",
                        'Energy Cost': f"${energy_charging:.2f}",
                        'Total': f"${swap_service + energy_charging + base_fee + location_premium + degradation_fee:.2f}",
                        'Rate': f"${energy_cost_per_kwh:.3f}/kWh"
                    }
                    
                    # Only add hybrid pricing columns if they have non-zero values
                    if base_fee > 0:
                        swap_row['Base Fee'] = f"${base_fee:.2f}"
                    if location_premium > 0:
                        swap_row['Location Premium'] = f"${location_premium:.2f}"
                    if degradation_fee > 0:
                        swap_row['Degradation'] = f"${degradation_fee:.2f}"
                    
                    cost_breakdown.append(swap_row)
            
            if cost_breakdown:
                cost_df = pd.DataFrame(cost_breakdown)
                
                # Simplified cost components chart
                st.markdown("**💰 Total Cost Breakdown**")
                
                col_chart1, col_chart2 = st.columns(2)
                
                with col_chart1:
                    # Main cost categories
                    main_costs = {
                        'Container Service': total_swap_service_cost,
                        'Energy Charging': total_energy_charging_cost,
                    }
                    
                    # Add hybrid components if used
                    if total_base_fees > 0:
                        main_costs['Base Fees'] = total_base_fees
                    if total_location_premium > 0:
                        main_costs['Location Premium'] = total_location_premium
                    if total_degradation > 0:
                        main_costs['Degradation'] = total_degradation
                    
                    main_df = pd.DataFrame(list(main_costs.items()), columns=['Category', 'Cost ($)'])
                    st.bar_chart(main_df.set_index('Category'), height=250)
                
                with col_chart2:
                    st.markdown("**💵 Cost Summary**")
                    st.metric("Container Services", f"${total_swap_service_cost:.2f}")
                    st.metric("Energy Charging", f"${total_energy_charging_cost:.2f}")
                    if total_base_fees > 0:
                        st.metric("Base Fees", f"${total_base_fees:.2f}")
                    if total_location_premium > 0:
                        st.metric("Location Premiums", f"${total_location_premium:.2f}")
                    if total_degradation > 0:
                        st.metric("Degradation Fees", f"${total_degradation:.2f}")
                    
                    grand_total_swap = (total_swap_service_cost + total_energy_charging_cost + 
                                       total_base_fees + total_location_premium + total_degradation)
                    st.metric("**Grand Total**", f"${grand_total_swap:.2f}", 
                             help="Total of all swap-related costs")
                
                # Detailed cost table
                st.markdown("---")
                st.markdown("**📋 Detailed Swap Costs by Station**")
                st.dataframe(
                    cost_df,
                    width='stretch',
                    hide_index=True
                )
                
                st.info(f"""
                **💡 Cost Breakdown Explanation:**
                - **Container Service**: ${total_swap_service_cost:.2f} - Physical swap handling fee
                - **Energy Charging**: ${total_energy_charging_cost:.2f} - Actual electricity cost for energy recharged
                - **Total Swap Costs**: ${grand_total_swap:.2f}
                
                **Note**: Energy cost is calculated based on **actual kWh charged**, not full battery capacity.
                Only the energy needed to recharge from current SoC to 100% is billed.
                """)
            else:
                st.info("✨ **No swaps performed!** Zero swap costs - journey completed on initial charge.")
        
        with viz_tab3:
            st.markdown("#### Segment-by-Segment Analysis")
            
            # Build simpler, clearer analysis
            segment_analysis = []
            for idx, row in steps_df.iterrows():
                segment = row['Segment']
                soc_before = row['SoC Before (kWh)']
                soc_after = row['SoC After Segment (kWh)']
                swapped = row['Swap']
                
                # Get segment details
                segment_key = segment.replace('->', '-')
                distance = config.get('distances_nm', {}).get(segment_key, 0)
                current = config.get('currents_knots', {}).get(segment_key, 0)
                base_consumption = config.get('base_consumption_per_nm', 220)
                
                # Calculate actual energy consumed
                energy_consumed = soc_before - soc_after
                
                # Calculate what was required for this segment
                multiplier = 1.2 if current < 0 else 0.8
                energy_required = distance * base_consumption * multiplier
                
                # Status indicators
                if swapped:
                    status = "🔋 Swapped before segment"
                    battery_status = f"Recharged to {battery_cap:.0f} kWh"
                elif soc_after < (battery_cap * 0.2):
                    status = "⚠️ Low battery after segment"
                    battery_status = f"Dropped to {soc_after:.0f} kWh"
                else:
                    status = "✅ Sufficient battery"
                    battery_status = f"Ended at {soc_after:.0f} kWh"
                
                flow_direction = "⬆️ Upstream (harder)" if current < 0 else "⬇️ Downstream (easier)"
                
                segment_analysis.append({
                    'Segment': segment,
                    'Distance': f"{distance:.1f} NM",
                    'Flow': flow_direction,
                    'Required': f"{energy_required:.0f} kWh",
                    'Available': f"{soc_before:.0f} kWh",
                    'Used': f"{energy_consumed:.0f} kWh",
                    'Remaining': f"{soc_after:.0f} kWh",
                    'Status': status
                })
            
            segment_df = pd.DataFrame(segment_analysis)
            
            st.markdown("**📊 Journey Breakdown**")
            st.info("""
            This shows what happened at each segment:
            - **Required**: Energy needed for this segment (accounting for river flow)
            - **Available**: Battery charge at start of segment
            - **Used**: Actual energy consumed during travel
            - **Remaining**: Battery charge at end of segment
            """)
            
            st.dataframe(
                segment_df,
                width='stretch',
                hide_index=True,
                column_config={
                    "Segment": st.column_config.TextColumn("Segment", width="small"),
                    "Distance": st.column_config.TextColumn("Distance", width="small"),
                    "Flow": st.column_config.TextColumn("River Flow", width="medium"),
                    "Required": st.column_config.TextColumn("Required", width="small"),
                    "Available": st.column_config.TextColumn("Had", width="small"),
                    "Used": st.column_config.TextColumn("Used", width="small"),
                    "Remaining": st.column_config.TextColumn("Left", width="small"),
                    "Status": st.column_config.TextColumn("Status", width="medium"),
                }
            )
            
            # Energy efficiency chart
            st.markdown("**⚡ Energy Efficiency by Segment**")
            
            efficiency_data = []
            for idx, row in steps_df.iterrows():
                segment = row['Segment']
                segment_key = segment.replace('->', '-')
                distance = config.get('distances_nm', {}).get(segment_key, 0)
                energy_consumed = row['SoC Before (kWh)'] - row['SoC After Segment (kWh)']
                
                # Energy per nautical mile
                energy_per_nm = energy_consumed / distance if distance > 0 else 0
                
                efficiency_data.append({
                    'Segment': segment,
                    'kWh per NM': energy_per_nm
                })
            
            efficiency_df = pd.DataFrame(efficiency_data)
            chart_data = efficiency_df.set_index('Segment')
            st.bar_chart(chart_data, height=250)
            
            st.caption("📈 Higher values = more energy consumed (upstream segments use more energy)")
        
        
        with viz_tab4:
            st.markdown("#### Swap Decision Analysis")
            
            if swap_cost_details:
                # Build swap analysis
                swap_analysis = []
                for detail in swap_cost_details:
                    remaining_pct = (detail['soc_before'] / battery_cap) * 100
                    
                    swap_analysis.append({
                        'Station': detail['station_name'],
                        'SoC Before Swap': f"{detail['soc_before']:.1f} kWh ({remaining_pct:.1f}%)",
                        'Energy Rate': f"${detail['energy_rate']:.3f}/kWh",
                        'Service Fee': f"${detail['swap_service']:.2f}",
                        'Energy Cost': f"${detail['energy_charging']:.2f}",
                        'Total Cost': f"${detail['total_cost']:.2f}",
                        'Decision': '✅ Swapped'
                    })
                
                swap_analysis_df = pd.DataFrame(swap_analysis)
                
                st.dataframe(
                    swap_analysis_df,
                    use_container_width=True,
                    hide_index=True
                )
                
                avg_soc_before = sum([d['soc_before'] for d in swap_cost_details]) / len(swap_cost_details)
                st.success(f"""
                **✅ Swap Optimization Summary:**
                - Total swaps performed: {len(swap_cost_details)}
                - Average remaining SoC at swap: {avg_soc_before:.1f} kWh ({(avg_soc_before/battery_cap)*100:.1f}%)
                - Optimizer chose these stations to minimize total cost while ensuring journey completion
                - Hybrid pricing model applied: service fees + energy (SoC-based) + location premiums + peak surcharges - discounts
                """)
            else:
                st.info("✨ **No swaps needed!** Battery capacity sufficient for entire journey.")

        st.markdown("---")
        
        # Download buttons
        st.markdown("### 📥 Export Results")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.download_button(
                "📄 Download Journey Plan (CSV)",
                data=steps_df.to_csv(index=False),
                file_name="journey_plan.csv",
                mime="text/csv",
                width='stretch',
                help="Download detailed journey plan as CSV"
            )
        
        with col2:
            st.download_button(
                "📋 Download Scenario (JSON)",
                data=json.dumps(config, indent=2),
                file_name="scenario.json",
                mime="application/json",
                width='stretch',
                help="Save scenario configuration for later use"
            )
        
        with col3:
            # Create summary report
            summary = f"""Riverboat Journey Summary
{'='*50}
Total Cost: ${totals['total_cost']:.2f}
Total Time: {totals['total_time']:.2f} hours
Arrival Time: {totals['finish_time']:.2f} hours
Battery Swaps: {swaps_count}

Average SoC: {avg_soc:.1f} kWh
Minimum SoC: {min_soc:.1f} kWh
Maximum SoC: {max_soc:.1f} kWh
"""
            st.download_button(
                "📊 Download Summary (TXT)",
                data=summary,
                file_name="journey_summary.txt",
                mime="text/plain",
                width='stretch',
                help="Download summary report as text file"
            )


def main() -> None:
    st.set_page_config(
        page_title="Riverboat Battery Swapping", 
        layout="wide",
        page_icon="🚢",
        initial_sidebar_state="expanded"
    )
    
    st.title("🚢 Riverboat Battery Swapping Optimiser")
    st.markdown("---")

    default_config = load_default_config()

    with st.sidebar:
        st.header("⚙️ Configuration")
        editor_choice = st.radio(
            "Input Method", 
            ("📝 Interactive Form", "📋 JSON Editor"),
            help="Choose how you want to configure your scenario"
        )
        
        st.markdown("---")
        
        run_button = st.button(
            "🚀 Run Optimisation", 
            type="primary",
            width='stretch'
        )
        
        if run_button:
            st.markdown("✅ **Running optimisation...**")

    if editor_choice == "📝 Interactive Form":
        # Route Configuration
        with st.expander("🗺️ Route Configuration", expanded=True):
            st.markdown("**Define your journey route**")
            
            col1, col2 = st.columns([1, 2])
            with col1:
                num_stations = st.number_input(
                    "How many stations?",
                    min_value=2,
                    value=5,  # Default to 5 stations instead of the full 20-station route
                    step=1,
                    help="Total number of stations including start and end"
                )
            
            with col2:
                st.info(f"📍 You'll have **{num_stations}** stations and **{num_stations-1}** segments to configure")
            
            # Generate station names
            st.markdown("**Station Names**")
            cols = st.columns(min(5, num_stations))
            station_names = []
            
            for i in range(num_stations):
                with cols[i % 5]:
                    default_name = default_config["route"][i] if i < len(default_config["route"]) else chr(65 + i)
                    name = st.text_input(
                        f"Station {i+1}",
                        value=default_name,
                        key=f"station_name_{i}",
                        help=f"Name for station #{i+1}"
                    )
                    station_names.append(name)
            
            route_text = ", ".join(station_names)

        # Segment Configuration
        with st.expander("🛤️ Segment Details", expanded=True):
            st.markdown("**Configure distance and river flow for each segment**")
            st.info("💡 **Flow Direction**: Upstream = traveling against river flow (harder), Downstream = traveling with river flow (easier)")
            
            # Build segment data based on current stations
            segment_rows = []
            for i in range(len(station_names) - 1):
                start_name = station_names[i]
                end_name = station_names[i + 1]
                key = f"{start_name}-{end_name}"
                
                # Try to get default values if they exist
                default_dist = default_config["distances_nm"].get(key, 40.0)
                default_curr = default_config["currents_knots"].get(key, 0.0)
                
                # Convert to absolute value and direction
                flow_speed = abs(default_curr)
                flow_direction = "Upstream" if default_curr < 0 else "Downstream"
                
                segment_rows.append({
                    "Start": start_name,
                    "End": end_name,
                    "Distance (NM)": default_dist,
                    "Flow Speed (knots)": flow_speed,
                    "Direction": flow_direction,
                })
            
            segments_df = pd.DataFrame(segment_rows)
            
            segments_df = st.data_editor(
                segments_df,
                width='stretch',
                key="segments_editor",
                column_config={
                    "Start": st.column_config.TextColumn("Start Station", width="small", disabled=True),
                    "End": st.column_config.TextColumn("End Station", width="small", disabled=True),
                    "Distance (NM)": st.column_config.NumberColumn(
                        "Distance (NM)",
                        min_value=0.1,
                        format="%.1f NM",
                        help="Distance between stations in Nautical Miles"
                    ),
                    "Flow Speed (knots)": st.column_config.NumberColumn(
                        "Flow Speed (knots)",
                        min_value=0.0,
                        format="%.1f knots",
                        help="River flow speed (always positive - direction shown separately)"
                    ),
                    "Direction": st.column_config.SelectboxColumn(
                        "Flow Direction",
                        width="medium",
                        options=["Upstream", "Downstream"],
                        help="Upstream = against flow (1.2× energy), Downstream = with flow (0.8× energy)"
                    ),
                },
                hide_index=True
            )

        # Station Configuration
        with st.expander("🔋 Station Settings", expanded=True):
            st.markdown("**Configure battery swap facilities at each station**")
            
            # Global controls for all stations
            st.markdown("#### 🎛️ Quick Settings (Apply to All Stations)")
            ctrl_col1, ctrl_col2, ctrl_col3, ctrl_col4 = st.columns(4)
            
            with ctrl_col1:
                global_swap_cost = st.slider(
                    "💰 Swap Cost ($)",
                    min_value=0.0,
                    max_value=500.0,
                    value=235.0,  # Based on actual containerized battery swap economics
                    step=10.0,
                    help="Adjust cost for all stations at once. Industry standard: $220-300 per container"
                )
            
            with ctrl_col2:
                global_swap_time = st.slider(
                    "⏱️ Swap Time (hr)",
                    min_value=0.1,
                    max_value=2.0,
                    value=0.75,  # 45 minutes - realistic for containerized battery swap
                    step=0.1,
                    help="Time to swap battery container with standard handling equipment (all stations)"
                )
            
            with ctrl_col3:
                global_queue_time = st.slider(
                    "⏳ Queue Time (hr)",
                    min_value=0.0,
                    max_value=2.0,
                    value=0.0,
                    step=0.1,
                    help="Average queue wait (all stations)"
                )
            
            with ctrl_col4:
                global_partial_swap = st.checkbox(
                    "🔄 Partial Swap",
                    value=False,
                    help="Apply partial swap option to all stations (only swap depleted containers for cost optimization)"
                )
            
            st.markdown("---")
            st.markdown("#### 📋 Individual Station Controls")
            
            # Build station data with individual controls
            station_rows = []
            for idx, name in enumerate(station_names):
                # Try to get default values if they exist
                default_swap_settings = default_config.get("swap_settings", {})
                default_station = default_swap_settings.get(name, {})
                
                # Create expandable section for each station
                with st.expander(f"🏪 {name}", expanded=(idx < 2)):
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.markdown("**💰 Swap Cost**")
                        station_cost = st.slider(
                            "Cost ($)",
                            min_value=0.0,
                            max_value=500.0,  # Increased max for realistic costs
                            value=global_swap_cost,
                            step=10.0,
                            key=f"cost_{name}",
                            label_visibility="collapsed"
                        )
                        st.caption(f"${station_cost:.2f}")
                    
                    with col2:
                        st.markdown("**⏱️ Swap Time**")
                        station_swap_time = st.slider(
                            "Swap Time (hr)",
                            min_value=0.1,
                            max_value=2.0,
                            value=global_swap_time,
                            step=0.1,
                            key=f"swap_time_{name}",
                            label_visibility="collapsed"
                        )
                        st.caption(f"{station_swap_time:.1f} hr")
                    
                    with col3:
                        st.markdown("**⏳ Queue Time**")
                        station_queue_time = st.slider(
                            "Queue Time (hr)",
                            min_value=0.0,
                            max_value=2.0,
                            value=global_queue_time,
                            step=0.1,
                            key=f"queue_time_{name}",
                            label_visibility="collapsed"
                        )
                        st.caption(f"{station_queue_time:.1f} hr")
                    
                    # Additional settings in columns
                    st.markdown("---")
                    col4, col5 = st.columns(2)
                    
                    with col4:
                        allow_swap = st.checkbox(
                            "✅ Swap Available",
                            value=default_station.get("allow_swap", True),
                            key=f"allow_{name}",
                            help="Enable battery swapping at this station"
                        )
                        force_swap = st.checkbox(
                            "⚠️ Force Swap",
                            value=default_station.get("force_swap", False),
                            key=f"force_{name}",
                            help="Require swap at this station (for inspection/maintenance)"
                        )
                        partial_swap = st.checkbox(
                            "🔄 Partial Swap Allowed",
                            value=global_partial_swap if global_partial_swap else default_station.get("partial_swap_allowed", False),
                            key=f"partial_{name}",
                            help="If enabled, only swap depleted containers (cost-optimized). If disabled, swap entire battery set (standard practice)"
                        )
                    
                    with col5:
                        batteries = st.number_input(
                            "🔋 Battery Stock",
                            min_value=0,
                            value=default_station.get("available_batteries", 7),
                            key=f"batteries_{name}",
                            help="Number of fully charged battery containers available"
                        )
                    
                    # Operating hours
                    col6, col7 = st.columns(2)
                    with col6:
                        open_hour = st.number_input(
                            "🌅 Opens (hr)",
                            min_value=0.0,
                            max_value=24.0,
                            value=default_station.get("open_hour", 0.0),
                            step=0.5,
                            key=f"open_{name}"
                        )
                    
                    with col7:
                        close_hour = st.number_input(
                            "🌙 Closes (hr)",
                            min_value=0.0,
                            max_value=24.0,
                            value=default_station.get("close_hour", 24.0),
                            step=0.5,
                            key=f"close_{name}"
                        )
                    
                    # Energy pricing at this station
                    st.markdown("---")
                    st.markdown("**💵 Basic Pricing**")
                    energy_cost_station = st.number_input(
                        "⚡ Energy Cost ($/kWh)",
                        min_value=0.0,
                        max_value=1.0,
                        value=default_station.get("energy_cost_per_kwh", 0.09),
                        step=0.01,
                        format="%.3f",
                        key=f"energy_cost_{name}",
                        help="Local electricity price at this station. Reference: Guangzhou/Zhao Qing ~$0.09/kWh, Hong Kong ~$0.18/kWh"
                    )
                
                # Collect data from UI elements
                station_rows.append({
                    "Station": name,
                    "Allow Swap": allow_swap,
                    "Force Swap": force_swap,
                    "Partial Swap": partial_swap,
                    "Swap Cost": station_cost,
                    "Swap Time (hr)": station_swap_time,
                    "Queue Time (hr)": station_queue_time,
                    "Open Hour": open_hour,
                    "Close Hour": close_hour,
                    "Available Batteries": batteries,
                    "Energy Cost ($/kWh)": energy_cost_station,
                })
            
            stations_df = pd.DataFrame(station_rows)

        # Global Parameters - Simplified & Clean
        with st.expander("⚙️ Global Parameters", expanded=True):
            st.markdown("### 🚢 Vessel Configuration")
            
            col1, col2 = st.columns(2)
    
        with col1:
            vessel_gt = st.number_input(
                "Vessel Gross Tonnage (GT)",
                min_value=100,
                max_value=20000,
                value=2000,
                step=100,
                help="Vessel size - determines battery capacity limits"
            )
        
            boat_speed = st.slider(
                "Boat Speed (knots)",
                min_value=3.0,
                max_value=20.0,
                value=float(default_config["boat_speed_knots"]),
                step=0.5,
                help="Maximum speed in still water"
            )
            
            start_time = st.slider(
                "Departure Time (hour)",
                min_value=0.0,
                max_value=24.0,
                value=float(default_config["start_time_hr"]) % 24,
                step=0.5,
                format="%.1f:00",
                help="Journey start time (24-hour format)"
            )
    
        with col2:
            base_consumption = st.slider(
                "Energy Consumption (kWh/NM)",
                min_value=10.0,
                max_value=400.0,
                value=float(default_config["base_consumption_per_nm"]),
                step=5.0,
                help="Energy per nautical mile. See benchmarks below"
            )
            
            time_cost = st.number_input(
                "Time Cost ($/hr)",
                min_value=0.0,
                value=float(default_config["time_cost_per_hr"]),
                step=1.0,
                format="%.2f",
                help="Opportunity cost per hour (crew wages, downtime)"
            )
    
    # Vessel benchmarks reference
    with st.expander("📖 Vessel Type Benchmarks", expanded=False):
        st.markdown(f"""
        **Energy Consumption per Nautical Mile (kWh/NM)**
        
        | Vessel Type | kWh/NM | Notes |
        |-------------|--------|-------|
        | Small Ferry | 83-100 | Short routes, frequent charging |
        | Harbor Tug | 233-350 | High peak loads, maneuvering |
        | Coastal Ferry | 200-267 | Medium routes, faster speeds |
        | Inland Cargo | 30-50 | Steady operations, optimized |
        
        **Your Current Setting**: `{base_consumption:.1f} kWh/NM`
        """)
    
    st.markdown("---")
    st.markdown("### 🔋 Battery System")
    
    col1, col2 = st.columns(2)
    
    with col1:
        battery_chemistry = st.selectbox(
            "Battery Chemistry",
            options=[
                "LFP (Lithium Iron Phosphate)",
                "NMC (Lithium Nickel Manganese Cobalt)",
                "LTO (Lithium Titanate Oxide)"
            ],
            index=0,
            help="Battery type - affects weight and safety"
        )
    
    # Simplified chemistry specs (removed Lead-Acid, Ni-Cd for clarity)
    chemistry_specs = {
        "LFP (Lithium Iron Phosphate)": {
            "density_min": 90,
            "density_max": 160,
            "density_typical": 120,
            "safety": "⭐⭐⭐⭐⭐",
            "features": "Best safety, long cycle life"
        },
        "NMC (Lithium Nickel Manganese Cobalt)": {
            "density_min": 150,
            "density_max": 220,
            "density_typical": 200,
            "safety": "⭐⭐⭐",
            "features": "Highest density, best range"
        },
        "LTO (Lithium Titanate Oxide)": {
            "density_min": 60,
            "density_max": 120,
            "density_typical": 90,
            "safety": "⭐⭐⭐⭐⭐",
            "features": "Very safe, fast charging, heavy"
        }
    }
    
    selected_chem = chemistry_specs[battery_chemistry]
    
    with col2:
        energy_density = st.slider(
            "Energy Density (Wh/kg)",
            min_value=float(selected_chem["density_min"]),
            max_value=float(selected_chem["density_max"]),
            value=float(selected_chem["density_typical"]),
            step=5.0,
            help=f"{selected_chem['features']} | Safety: {selected_chem['safety']}"
        )
    
    # Battery chemistry reference
    with st.expander("📖 Battery Chemistry Reference", expanded=False):
        st.markdown("""
        **Marine Battery Chemistry Comparison**
        
        | Chemistry | Wh/kg | Safety | Key Features |
        |-----------|-------|--------|--------------|
        | **LFP** | 90-160 | ⭐⭐⭐⭐⭐ | Best safety, long cycle life |
        | **NMC** | 150-220 | ⭐⭐⭐ | Highest density, best range |
        | **LTO** | 60-120 | ⭐⭐⭐⭐⭐ | Very safe, fast charging |
        """)
    
    st.markdown("---")
    st.info("💡 **Containerized System**: Configure battery containers for modular swapping")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        battery_container_capacity = st.number_input(
            "Container Capacity (kWh)",
            min_value=100.0,
            max_value=5000.0,
            value=float(default_config.get("battery_container_capacity_kwh", 1960.0)),
            step=50.0,
            help="Capacity per 20-foot ISO container. Standard: 1960 kWh"
        )
    
    with col2:
        num_containers = st.number_input(
            "Number of Containers",
            min_value=1,
            max_value=20,
            value=int(default_config["battery_capacity_kwh"] / default_config.get("battery_container_capacity_kwh", 1960.0)),
            step=1,
            help="Total battery containers on vessel"
        )
    
    # Calculate total capacity
    battery_capacity = battery_container_capacity * num_containers
    
    with col3:
        st.metric(
            "Total Capacity",
            f"{battery_capacity/1000:.2f} MWh",
            help=f"{battery_capacity:,.0f} kWh from {num_containers} containers"
        )
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        minimum_soc = st.slider(
            "Minimum SoC (%)",
            min_value=0.0,
            max_value=50.0,
            value=float(default_config["minimum_soc_fraction"]) * 100,
            step=5.0,
            help="Minimum battery charge to maintain"
        ) / 100.0
    
    with col2:
        soc_step = st.slider(
            "SoC Precision (kWh)",
            min_value=5.0,
            max_value=50.0,
            value=float(default_config["soc_step_kwh"]),
            step=5.0,
            help="Smaller = more precise, slower computation. 10-20 kWh recommended"
        )
    
    with col3:
        initial_soc_fraction = st.slider(
            "Initial SoC (%)",
            min_value=0.0,
            max_value=100.0,
            value=100.0,
            step=5.0,
            help="Starting charge percentage"
        ) / 100.0
        initial_soc_kwh = battery_capacity * initial_soc_fraction
    
    st.markdown("---")
    st.markdown("### 📊 System Analysis")
    
    # Calculate battery weight
    battery_weight_kg = (battery_capacity * 1000) / energy_density
    battery_weight_tonnes = battery_weight_kg / 1000
    
    # Calculate ranges
    max_range = battery_capacity / base_consumption if base_consumption > 0 else 0
    usable_battery = battery_capacity * (1 - minimum_soc)
    usable_range = usable_battery / base_consumption if base_consumption > 0 else 0
    weight_ratio = (battery_weight_tonnes / vessel_gt) * 100 if vessel_gt > 0 else 0
    
    # Display metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "⚖️ Battery Weight",
            f"{battery_weight_tonnes:.2f} t",
            help=f"Based on {energy_density:.0f} Wh/kg"
        )
    
    with col2:
        st.metric(
            "📈 Weight/GT Ratio",
            f"{weight_ratio:.1f}%",
            help=f"{battery_weight_tonnes:.2f}t / {vessel_gt}t"
        )
    
    with col3:
        st.metric(
            "🎯 Maximum Range",
            f"{max_range:.1f} NM",
            help="100% to 0% (theoretical)"
        )
    
    with col4:
        st.metric(
            "✅ Usable Range",
            f"{usable_range:.1f} NM",
            help=f"100% to {minimum_soc*100:.0f}% (practical)"
        )
    
    # Optional detailed view
    with st.expander("🔬 Detailed Calculations", expanded=False):
        st.markdown(f"""
        **Battery System:**
        - Chemistry: {battery_chemistry}
        - Containers: {num_containers} × {battery_container_capacity:.0f} kWh
        - Total Capacity: {battery_capacity:.0f} kWh ({battery_capacity/1000:.2f} MWh)
        - Usable Capacity: {usable_battery:.0f} kWh ({(1-minimum_soc)*100:.0f}%)
        - Energy Density: {energy_density:.0f} Wh/kg
        - Total Weight: {battery_weight_tonnes:.2f} tonnes
        - Weight per Container: {battery_weight_tonnes/num_containers:.2f} tonnes
        
        **Vessel Performance:**
        - Vessel GT: {vessel_gt:,.0f}
        - Battery/GT Ratio: {weight_ratio:.2f}%
        - Consumption: {base_consumption:.1f} kWh/NM
        - Max Range: {max_range:.1f} NM
        - Usable Range: {usable_range:.1f} NM
        """)
            
        # Chemistry comparison
        st.markdown("---")
        st.markdown(f"**Weight Comparison for {battery_capacity:.0f} kWh:**")
        
        comparison_data = []
        for chem_name, chem_data in chemistry_specs.items():
            typical_density = chem_data["density_typical"]
            weight_tonnes = (battery_capacity * 1000) / typical_density / 1000
            comparison_data.append({
                "Chemistry": chem_name.split(" (")[0],
                "Wh/kg": typical_density,
                "Weight (tonnes)": f"{weight_tonnes:.2f}",
                "Weight/GT %": f"{(weight_tonnes / vessel_gt * 100):.1f}%" if vessel_gt > 0 else "N/A"
            })
        
        comparison_df = pd.DataFrame(comparison_data)
        st.dataframe(comparison_df, use_container_width=True, hide_index=True)

    params = {
        "boat_speed": boat_speed,
        "base_consumption": base_consumption,
        "battery_capacity": battery_capacity,
        "battery_container_capacity": battery_container_capacity,
        "initial_soc_kwh": initial_soc_kwh,
        "minimum_soc": minimum_soc,
        "time_cost": time_cost,
        "soc_step": soc_step,
        "start_time": start_time,
    }

    if run_button:
        try:
            config = form_frames_to_config(route_text, segments_df, stations_df, params)
        except Exception as exc:
            st.error(f"Invalid scenario configuration: {exc}")
            st.stop()
    else:
        # JSON editor mode
        with st.expander("📋 JSON Configuration", expanded=True):
            st.markdown("**Edit scenario configuration as JSON**")
            config_text = st.text_area(
                "Scenario JSON",
                value=json.dumps(default_config, indent=2),
                height=450,
                help="Edit the JSON configuration directly for advanced control"
            )
        if run_button:
            try:
                config = json.loads(config_text)
            except json.JSONDecodeError as exc:
                st.error(f"Invalid JSON: {exc}")
                st.stop()
        else:
            config = default_config

    if run_button:
        with st.spinner("🔄 Computing optimal route..."):
            try:
                # Validate scenario before running
                route = config.get('route', [])
                total_distance = sum(config.get('distances_nm', {}).values())
                battery_capacity = config.get('battery_capacity_kwh', 0)
                base_consumption = config.get('base_consumption_per_nm', 0)
                min_soc_fraction = config.get('minimum_soc_fraction', 0)
                
                # Calculate theoretical range
                usable_battery = battery_capacity * (1 - min_soc_fraction)
                max_range = usable_battery / base_consumption if base_consumption > 0 else 0
                
                # Check if swap stations are available
                stations_with_swap = [s for s in route if config.get('stations', {}).get(s, {}).get('allow_swap', False)]
                
                # Only show warning if route is too long AND no swap stations are available
                if total_distance > max_range * 1.5 and not stations_with_swap:  # Allow some margin for currents
                    st.warning(f"""
                    ⚠️ **Potential Issue Detected**
                    
                    - **Total Route Distance**: {total_distance:.1f} NM
                    - **Battery Usable Range**: {max_range:.1f} NM
                    - **Number of Segments**: {len(route) - 1}
                    - **Swap Stations Available**: None
                    
                    The route may be too long for the battery capacity. Consider:
                    1. Increasing battery capacity
                    2. Reducing fuel consumption
                    3. Enabling swap stations on the route
                    4. Reducing minimum SoC requirement
                    """)
                
                steps_df, totals = run_optimizer(config)
                render_results(steps_df, totals, config)
                
            except ValueError as exc:
                st.error(f"❌ **No Feasible Solution Found**")
                st.error(f"**Error Details**: {str(exc)}")
                
                error_msg = str(exc)
                if "No feasible solution for final SoC requirement" in error_msg:
                    st.markdown("""
                    ### 🔍 Diagnosis
                    
                    The optimizer cannot find a valid solution. This usually means:
                    
                    1. **⚡ Insufficient Battery Range**
                       - Battery capacity is too small for the journey
                       - Energy consumption is too high
                       - Try: Increase battery capacity or reduce consumption
                    
                    2. **🔋 Swap Stations Not Available**
                       - No swap stations on the route, or
                       - Swap stations don't have batteries available, or
                       - Stations are closed during arrival times
                       - Try: Enable swaps at intermediate stations
                    
                    3. **⏰ Operating Hours Conflicts**
                       - Cannot reach swap stations during operating hours
                       - Try: Adjust departure time or station hours
                    
                    4. **🎯 Final SoC Requirement Too High**
                       - Cannot arrive with required minimum charge
                       - Try: Reduce minimum SoC percentage
                    
                    5. **🌊 Strong River Flow**
                       - Traveling upstream (against flow) consuming too much energy
                       - Try: Reduce upstream flow values or increase boat speed
                    """)
                    
                    # Show current configuration summary
                    with st.expander("📋 Current Configuration", expanded=True):
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.markdown("**Route Info**")
                            st.write(f"- Stations: {len(route)}")
                            st.write(f"- Segments: {len(route) - 1}")
                            st.write(f"- Total Distance: {total_distance:.1f} NM")
                        
                        with col2:
                            st.markdown("**Battery Info**")
                            st.write(f"- Capacity: {battery_capacity:.0f} kWh")
                            st.write(f"- Usable: {usable_battery:.0f} kWh ({(1-min_soc_fraction)*100:.0f}%)")
                            st.write(f"- Range: {max_range:.1f} NM")
                        
                        with col3:
                            st.markdown("**Energy Info**")
                            st.write(f"- Consumption: {base_consumption:.1f} kWh/NM")
                            st.write(f"- Est. Energy: {total_distance * base_consumption:.0f} kWh")
                            energy_deficit = (total_distance * base_consumption) - usable_battery
                            if energy_deficit > 0:
                                st.error(f"- ⚠️ Deficit: {energy_deficit:.0f} kWh")
                            else:
                                st.success(f"- ✅ Surplus: {-energy_deficit:.0f} kWh")
                        
                        # Check swap availability
                        stations_with_swap = [s for s in route if config.get('stations', {}).get(s, {}).get('allow_swap', False)]
                        st.markdown("**Swap Stations**")
                        if stations_with_swap:
                            st.write(f"- Available at: {', '.join(stations_with_swap)}")
                        else:
                            st.error("- ⚠️ No swap stations enabled!")
                        
                        # Detailed segment analysis
                        st.markdown("---")
                        st.markdown("**Segment-by-Segment Analysis**")
                        
                        segments_data = []
                        cumulative_distance = 0
                        cumulative_energy = 0
                        
                        for i in range(len(route) - 1):
                            start = route[i]
                            end = route[i + 1]
                            key = f"{start}-{end}"
                            
                            distance = config.get('distances_nm', {}).get(key, 0)
                            current = config.get('currents_knots', {}).get(key, 0)
                            boat_speed = config.get('boat_speed_knots', 5.0)
                            
                            # Calculate energy for this segment
                            segment_energy = distance * base_consumption
                            if current < 0:  # Upstream
                                segment_energy *= 1.2
                            else:  # Downstream
                                segment_energy *= 0.8
                            
                            cumulative_distance += distance
                            cumulative_energy += segment_energy
                            
                            flow_direction = "⬆️ Upstream" if current < 0 else "⬇️ Downstream"
                            
                            segments_data.append({
                                'Segment': f"{start}→{end}",
                                'Distance': f"{distance:.1f} NM",
                                'Flow': f"{abs(current):.1f} knots {flow_direction}",
                                'Energy': f"{segment_energy:.0f} kWh",
                                'Cumulative': f"{cumulative_energy:.0f} kWh"
                            })
                        
                        seg_df = pd.DataFrame(segments_data)
                        st.dataframe(seg_df, width='stretch', hide_index=True)
                        
                        # Energy balance check
                        st.markdown("---")
                        st.markdown("**Energy Balance Check**")
                        if cumulative_energy > usable_battery:
                            st.error(f"⚠️ **Total energy needed ({cumulative_energy:.0f} kWh) exceeds usable battery ({usable_battery:.0f} kWh)**")
                            st.error(f"Deficit: {cumulative_energy - usable_battery:.0f} kWh - **SWAP REQUIRED!**")
                            if not stations_with_swap:
                                st.error("❌ **But no swap stations are enabled!**")
                        else:
                            st.success(f"✅ Battery has enough capacity ({usable_battery:.0f} kWh) for total journey ({cumulative_energy:.0f} kWh)")
                else:
                    st.exception(exc)
                    
            except Exception as exc:
                st.error(f"❌ **Optimisation Failed**")
                st.exception(exc)
    else:
        # Welcome message when no optimisation has run
        st.info("👈 **Configure your scenario and click 'Run Optimisation' to get started!**")
        
        with st.expander("ℹ️ How to Use This Tool", expanded=False):
            st.markdown("""
            ### Getting Started
            
            1. **Choose Input Method** in the sidebar:
               - 📝 **Interactive Form**: Use sliders, inputs, and tables for easy configuration
               - 📋 **JSON Editor**: Edit raw JSON for advanced control
            
            2. **Configure Your Scenario**:
               - 🗺️ **Route**: Define the sequence of stations
               - 🛤️ **Segments**: Set distances and river flow between stations (positive = downstream, negative = upstream)
               - 🔋 **Stations**: Configure swap facilities, costs, and operating hours
               - ⚙️ **Parameters**: Set boat specs, battery capacity, and costs
            
            3. **Run Optimisation**: Click the button in the sidebar
            
            4. **Analyze Results**: Review the optimal swap strategy, costs, and timing
            
            5. **Export**: Download journey plans, scenarios, or summaries
            
            ### Tips
            - 💡 Hover over any field for helpful tooltips
            - 🔄 Try different scenarios to compare strategies
            - 💾 Save your scenarios as JSON for future use
            - 📊 Use the SoC chart to visualize battery levels throughout the journey
            - ⚡ See the **Vessel Energy Consumption Reference** in Global Parameters for realistic energy consumption values
            - 📖 Check `ENERGY_CONSUMPTION_REFERENCE.md` for detailed vessel specifications
            """)
        
        with st.expander("📖 Example Scenario", expanded=False):
            st.markdown("""
            **Sample Route**: A → B → C → D → E
            
            - **Total Distance**: 150 NM
            - **Swap Stations**: B, C, D (with varying costs and hours)
            - **Challenge**: Balance swap costs against energy consumption and time
            - **Goal**: Minimize total cost while maintaining minimum battery SoC
            
            The optimizer considers:
            - River flow (downstream/upstream travel)
            - Station operating hours and queue times
            - Energy costs vs swap costs vs time costs
            - Battery availability at each station
            """)


if __name__ == "__main__":
    main()
