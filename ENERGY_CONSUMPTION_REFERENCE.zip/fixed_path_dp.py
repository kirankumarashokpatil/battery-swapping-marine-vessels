from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass(frozen=True)
class SegmentOption:
    label: str
    travel_time_hr: float
    energy_kwh: float
    extra_cost: float = 0.0


@dataclass(frozen=True)
class Segment:
    start: str
    end: str
    options: List[SegmentOption]


@dataclass(frozen=True)
class Station:
    name: str
    swap_cost: float  # Cost per battery container swap (service fee component)
    swap_time_hr: float
    allow_swap: bool = True
    force_swap: bool = False
    partial_swap_allowed: bool = False  # If True, can swap only depleted containers; if False, must swap all
    queue_time_hr: float = 0.0
    operating_hours: Optional[Tuple[float, float]] = None
    available_batteries: Optional[int] = None
    energy_cost_per_kwh: float = 0.09  # Station-specific energy pricing (default: Guangzhou/Zhao Qing rate)
    
    # Hybrid/Custom Pricing Components (Current Direct-style model)
    base_service_fee: float = 0.0  # Fixed base fee per swap transaction (independent of container count)
    location_premium: float = 0.0  # Location-based markup ($ or % of base cost) for high-demand/strategic ports
    degradation_fee_per_kwh: float = 0.0  # Charge based on battery wear/degradation
    peak_hour_multiplier: float = 1.0  # Time-of-day pricing multiplier (e.g., 1.2 for peak hours)
    peak_hours: Optional[Tuple[float, float]] = None  # Peak pricing window (e.g., 8-18 for business hours)
    subscription_discount: float = 0.0  # Percentage discount for subscription customers (0.0-1.0)


@dataclass(frozen=True)
class FixedPathInputs:
    stations: List[Station]
    segments: List[Segment]
    battery_capacity_kwh: float  # Total battery system capacity
    battery_container_capacity_kwh: float  # Capacity per individual container (default: 1960 kWh)
    initial_soc_kwh: float
    final_soc_min_kwh: float
    energy_cost_per_kwh: float
    min_soc_kwh: float = 0.0
    time_cost_per_hr: float = 0.0
    soc_step_kwh: float = 1.0
    start_time_hr: float = 0.0

    def __post_init__(self) -> None:
        if len(self.stations) != len(self.segments) + 1:
            raise ValueError("stations count must be segments + 1")
        if self.initial_soc_kwh > self.battery_capacity_kwh:
            raise ValueError("initial SoC exceeds capacity")
        if self.initial_soc_kwh < self.min_soc_kwh:
            raise ValueError("initial SoC below minimum operating SoC")
        if self.soc_step_kwh <= 0:
            raise ValueError("SoC step must be positive")
        if self.final_soc_min_kwh < 0:
            raise ValueError("final SoC requirement must be non-negative")
        if self.min_soc_kwh < 0:
            raise ValueError("minimum operating SoC must be non-negative")
        if self.min_soc_kwh > self.battery_capacity_kwh:
            raise ValueError("minimum operating SoC exceeds capacity")
        if self.final_soc_min_kwh > self.battery_capacity_kwh:
            raise ValueError("final SoC requirement exceeds capacity")
        if self.final_soc_min_kwh < self.min_soc_kwh:
            raise ValueError("final SoC requirement cannot be below minimum operating SoC")
        for station in self.stations:
            if station.swap_time_hr < 0:
                raise ValueError(f"Station {station.name} swap time must be non-negative")
            if station.queue_time_hr < 0:
                raise ValueError(f"Station {station.name} queue time must be non-negative")
            if station.available_batteries is not None and station.available_batteries < 0:
                raise ValueError(f"Station {station.name} available batteries cannot be negative")


@dataclass(frozen=True)
class StepResult:
    station_name: str
    swap_taken: bool
    num_containers_swapped: int  # Number of battery containers swapped at this station
    arrival_time_hr: float
    departure_time_hr: float
    station_wait_time_hr: float
    station_queue_time_hr: float
    station_swap_time_hr: float
    soc_before_kwh: float
    soc_after_swap_kwh: float
    segment_label: str
    energy_used_kwh: float
    travel_time_hr: float
    soc_after_segment_kwh: float
    incremental_cost: float
    cumulative_cost: float
    incremental_time_hr: float
    cumulative_time_hr: float


@dataclass(frozen=True)
class OptimisationResult:
    total_cost: float
    total_time_hr: float
    finish_time_hr: float
    steps: List[StepResult]


@dataclass(frozen=True)
class _Transition:
    prev_level: int
    swapped: bool
    swap_cost: float
    station_wait_time_hr: float
    station_queue_time_hr: float
    station_swap_time_hr: float
    soc_after_swap_kwh: float
    option_index: int
    energy_kwh: float
    travel_time_hr: float
    energy_cost: float
    time_cost: float
    extra_cost: float

    @property
    def incremental_cost(self) -> float:
        return self.swap_cost + self.energy_cost + self.time_cost + self.extra_cost

    @property
    def incremental_time(self) -> float:
        return (
            self.station_wait_time_hr
            + self.station_queue_time_hr
            + self.station_swap_time_hr
            + self.travel_time_hr
        )


class FixedPathOptimizer:
    def __init__(self, inputs: FixedPathInputs) -> None:
        self.inputs = inputs
        cap_steps = self._to_step(inputs.battery_capacity_kwh)
        self._capacity_steps = cap_steps
        self._soc_levels = cap_steps + 1
        self._min_operating_level = self._to_step(inputs.min_soc_kwh)

    def solve(self) -> OptimisationResult:
        inputs = self.inputs
        # Track the station index where the current battery was charged for each state
        # dp_battery_source[station][soc_level] = station index where battery was obtained
        dp_cost = [[math.inf] * self._soc_levels for _ in inputs.stations]
        dp_time = [[math.inf] * self._soc_levels for _ in inputs.stations]
        dp_battery_source = [[-1] * self._soc_levels for _ in inputs.stations]
        prev: List[List[Optional[_Transition]]] = [
            [None] * self._soc_levels for _ in inputs.stations
        ]

        start_level = self._to_step(inputs.initial_soc_kwh)
        dp_cost[0][start_level] = 0.0
        dp_time[0][start_level] = 0.0
        dp_battery_source[0][start_level] = 0  # Initial battery from station 0

        for idx, segment in enumerate(inputs.segments):
            station = inputs.stations[idx]
            next_station = inputs.stations[idx + 1]
            for level in range(self._soc_levels):
                base_cost = dp_cost[idx][level]
                if not math.isfinite(base_cost):
                    continue
                base_time = dp_time[idx][level]
                battery_source_idx = dp_battery_source[idx][level]
                soc_before = self._from_step(level)
                arrival_time_hr = self.inputs.start_time_hr + base_time
                candidate_levels = self._candidate_levels(
                    station, level, arrival_time_hr
                )
                for (
                    level_after_swap,
                    swap_cost,
                    wait_time,
                    queue_time,
                    swap_time,
                    swapped,
                ) in candidate_levels:
                    # If swapped, battery comes from current station; else keep source
                    new_battery_source_idx = idx if swapped else battery_source_idx
                    battery_source_station = inputs.stations[new_battery_source_idx]
                    
                    soc_post_swap = self._from_step(level_after_swap)
                    for option_idx, option in enumerate(segment.options):
                        energy_steps = self._energy_to_steps(option.energy_kwh)
                        if level_after_swap < energy_steps:
                            continue
                        new_level = level_after_swap - energy_steps
                        if new_level < self._min_operating_level:
                            continue
                        travel_time = option.travel_time_hr
                        # Energy cost is already included in swap_cost at charging station
                        # No additional cost for consuming energy during travel
                        energy_cost = 0.0
                        dwell_time = wait_time + queue_time + swap_time
                        time_cost = (
                            (dwell_time + travel_time)
                            * inputs.time_cost_per_hr
                        )
                        new_cost = (
                            base_cost
                            + swap_cost
                            + option.extra_cost
                            + energy_cost
                            + time_cost
                        )
                        new_time = base_time + dwell_time + travel_time
                        if self._improves(new_cost, new_time, dp_cost[idx + 1][new_level], dp_time[idx + 1][new_level]):
                            dp_cost[idx + 1][new_level] = new_cost
                            dp_time[idx + 1][new_level] = new_time
                            dp_battery_source[idx + 1][new_level] = new_battery_source_idx
                            prev[idx + 1][new_level] = _Transition(
                                prev_level=level,
                                swapped=swapped,
                                swap_cost=swap_cost,
                                station_wait_time_hr=wait_time,
                                station_queue_time_hr=queue_time,
                                station_swap_time_hr=swap_time,
                                soc_after_swap_kwh=soc_post_swap,
                                option_index=option_idx,
                                energy_kwh=option.energy_kwh,
                                travel_time_hr=travel_time,
                                energy_cost=energy_cost,
                                time_cost=(dwell_time + travel_time)
                                * inputs.time_cost_per_hr,
                                extra_cost=option.extra_cost,
                            )

        best_level, best_cost, best_time = self._select_terminal_state(dp_cost, dp_time)
        steps = self._reconstruct(prev, best_level, best_cost, best_time, dp_cost, dp_time)
        finish_time_hr = self.inputs.start_time_hr + best_time
        return OptimisationResult(
            total_cost=best_cost,
            total_time_hr=best_time,
            finish_time_hr=finish_time_hr,
            steps=steps,
        )

    def _candidate_levels(
        self, station: Station, level: int, arrival_time_hr: float
    ) -> List[Tuple[int, float, float, float, float, bool]]:
        options: List[Tuple[int, float, float, float, float, bool]] = []

        if station.force_swap and not station.allow_swap:
            raise ValueError(
                f"Station {station.name} requires swap but swap not allowed"
            )

        if not station.force_swap:
            options.append((level, 0.0, 0.0, 0.0, 0.0, False))

        if station.allow_swap:
            if station.available_batteries is not None and station.available_batteries < 1:
                if station.force_swap:
                    raise ValueError(
                        f"Station {station.name} requires swap but no batteries available"
                    )
            else:
                capacity_level = self._capacity_steps
                dwell_required = station.queue_time_hr + station.swap_time_hr
                wait_time = self._station_wait_time(station, arrival_time_hr, dwell_required)
                
                # Calculate swap cost based on full vs partial swap mode
                total_num_containers = int(self.inputs.battery_capacity_kwh / self.inputs.battery_container_capacity_kwh)
                if total_num_containers < 1:
                    total_num_containers = 1
                
                # Determine how many containers need swapping
                current_soc_kwh = self._from_step(level)
                if station.partial_swap_allowed:
                    # PARTIAL SWAP: Only swap depleted containers (those below full capacity)
                    containers_to_swap = total_num_containers - int(current_soc_kwh / self.inputs.battery_container_capacity_kwh)
                    if containers_to_swap < 0:
                        containers_to_swap = 0
                    # If any energy is missing, swap at least one container
                    if current_soc_kwh < self.inputs.battery_capacity_kwh and containers_to_swap == 0:
                        containers_to_swap = 1
                else:
                    # FULL SWAP: Always swap entire battery set
                    containers_to_swap = total_num_containers
                
                # HYBRID PRICING MODEL (Industry Standard - Current Direct Style)
                # Based on marine BaaS best practices with SoC-based billing
                
                # Component 1: Base Service Fee (fixed per transaction)
                base_fee = station.base_service_fee
                
                # Component 2: Per-Container Service Cost (handling/logistics fee)
                per_container_service = station.swap_cost * containers_to_swap
                
                # Component 3: Location Premium (strategic port surcharge)
                location_cost = station.location_premium * containers_to_swap
                
                # Component 4: Energy Cost - NET ENERGY DIFFERENCE METHOD
                # Industry Standard: Charge only for the energy difference between 
                # returned battery SoC and fully charged battery provided
                # Example: Return 50% battery, get 100% battery → Pay for 50% energy
                energy_kwh_needed = self.inputs.battery_capacity_kwh - current_soc_kwh
                energy_cost = energy_kwh_needed * station.energy_cost_per_kwh
                
                # Component 5: Degradation Fee (battery wear based on actual kWh cycled)
                # Reflects battery lifecycle cost - charged per kWh of energy difference
                degradation_cost = energy_kwh_needed * station.degradation_fee_per_kwh
                
                # Component 6: Peak Hour Pricing
                time_of_day = arrival_time_hr % 24.0
                peak_multiplier = 1.0
                if station.peak_hours is not None:
                    peak_start, peak_end = station.peak_hours
                    if peak_start <= time_of_day < peak_end:
                        peak_multiplier = station.peak_hour_multiplier
                
                # Calculate total before discounts
                subtotal = (
                    base_fee +
                    per_container_service +
                    location_cost +
                    energy_cost +
                    degradation_cost
                ) * peak_multiplier
                
                # Component 7: Subscription Discount
                total_swap_cost = subtotal * (1.0 - station.subscription_discount)
                
                if station.force_swap or (
                    level != capacity_level
                    or station.swap_cost
                    or station.swap_time_hr
                    or station.queue_time_hr
                    or wait_time
                ):
                    options.append(
                        (
                            capacity_level,
                            total_swap_cost,  # Total cost with hybrid pricing model
                            wait_time,
                            station.queue_time_hr,
                            station.swap_time_hr,
                            True,
                        )
                    )

        return options

    def _station_wait_time(
        self, station: Station, arrival_time_hr: float, dwell_time_hr: float
    ) -> float:
        if not station.allow_swap or station.operating_hours is None:
            return 0.0
        if dwell_time_hr < -1e-9:
            raise ValueError("Dwell time cannot be negative")
        windows = self._daily_windows(station)
        if not windows:
            return 0.0
        tolerance = 1e-9
        max_window = max(window_end - window_start for window_start, window_end in windows)
        if max_window + tolerance < dwell_time_hr:
            raise ValueError(
                f"Station {station.name} dwell requirement exceeds operating window"
            )

        time_cursor = arrival_time_hr
        for _ in range(14):
            mod_time = time_cursor % 24.0
            day_start = time_cursor - mod_time
            for window_start, window_end in windows:
                window_start_abs = day_start + window_start
                window_end_abs = day_start + window_end
                if mod_time <= window_start:
                    candidate_start = window_start_abs
                elif window_start <= mod_time < window_end:
                    candidate_start = time_cursor
                else:
                    continue
                candidate_end = candidate_start + dwell_time_hr
                if candidate_end <= window_end_abs + tolerance:
                    return candidate_start - arrival_time_hr
            time_cursor = day_start + 24.0

        raise ValueError(
            f"Unable to schedule swap at station {station.name} within operating hours"
        )

    @staticmethod
    def _daily_windows(station: Station) -> List[Tuple[float, float]]:
        if station.operating_hours is None:
            return []
        open_hr, close_hr = station.operating_hours
        open_mod = open_hr % 24.0
        close_mod = close_hr % 24.0
        if math.isclose(open_mod, close_mod, abs_tol=1e-9):
            return [(0.0, 24.0)]
        if open_mod < close_mod:
            return [(open_mod, close_mod)]
        return [(open_mod, 24.0), (0.0, close_mod)]

    def _select_terminal_state(
        self,
        dp_cost: List[List[float]],
        dp_time: List[List[float]],
    ) -> Tuple[int, float, float]:
        inputs = self.inputs
        final_idx = len(inputs.stations) - 1
        min_level = self._to_step(inputs.final_soc_min_kwh)
        best_level = -1
        best_cost = math.inf
        best_time = math.inf
        for level in range(min_level, self._soc_levels):
            cost = dp_cost[final_idx][level]
            if not math.isfinite(cost):
                continue
            time = dp_time[final_idx][level]
            if self._improves(cost, time, best_cost, best_time):
                best_cost = cost
                best_time = time
                best_level = level
        if best_level < 0:
            raise ValueError("No feasible solution for final SoC requirement")
        return best_level, best_cost, best_time

    def _reconstruct(
        self,
        prev: List[List[Optional[_Transition]]],
        level: int,
        best_cost: float,
        best_time: float,
        dp_cost: List[List[float]],
        dp_time: List[List[float]],
    ) -> List[StepResult]:
        steps: List[StepResult] = []
        idx = len(self.inputs.stations) - 1
        current_level = level
        cumulative_cost = best_cost
        cumulative_time = best_time
        while idx > 0:
            transition = prev[idx][current_level]
            if transition is None:
                raise RuntimeError("Missing transition during reconstruction")
            prev_level = transition.prev_level
            station = self.inputs.stations[idx - 1]
            segment = self.inputs.segments[idx - 1]
            option = segment.options[transition.option_index]
            soc_before = self._from_step(prev_level)
            soc_after_segment = self._from_step(current_level)
            step_cost = transition.incremental_cost
            step_time = transition.incremental_time
            arrival_elapsed = dp_time[idx - 1][prev_level]
            arrival_time_hr = self.inputs.start_time_hr + arrival_elapsed
            dwell_time = (
                transition.station_wait_time_hr
                + transition.station_queue_time_hr
                + transition.station_swap_time_hr
            )
            departure_time_hr = arrival_time_hr + dwell_time
            
            # Calculate number of containers swapped
            num_containers_swapped = 0
            if transition.swapped:
                total_num_containers = int(self.inputs.battery_capacity_kwh / self.inputs.battery_container_capacity_kwh)
                if total_num_containers < 1:
                    total_num_containers = 1
                
                # Determine actual containers swapped based on station policy
                if station.partial_swap_allowed:
                    # PARTIAL SWAP: Calculate how many containers were depleted
                    containers_to_swap = total_num_containers - int(soc_before / self.inputs.battery_container_capacity_kwh)
                    if containers_to_swap < 0:
                        containers_to_swap = 0
                    # If any energy is missing, at least one container was swapped
                    if soc_before < self.inputs.battery_capacity_kwh and containers_to_swap == 0:
                        containers_to_swap = 1
                    num_containers_swapped = containers_to_swap
                else:
                    # FULL SWAP: All containers swapped
                    num_containers_swapped = total_num_containers
            
            steps.append(
                StepResult(
                    station_name=station.name,
                    swap_taken=transition.swapped,
                    num_containers_swapped=num_containers_swapped,
                    arrival_time_hr=arrival_time_hr,
                    departure_time_hr=departure_time_hr,
                    station_wait_time_hr=transition.station_wait_time_hr,
                    station_queue_time_hr=transition.station_queue_time_hr,
                    station_swap_time_hr=transition.station_swap_time_hr,
                    soc_before_kwh=soc_before,
                    soc_after_swap_kwh=transition.soc_after_swap_kwh,
                    segment_label=option.label,
                    energy_used_kwh=transition.energy_kwh,
                    travel_time_hr=transition.travel_time_hr,
                    soc_after_segment_kwh=soc_after_segment,
                    incremental_cost=step_cost,
                    cumulative_cost=cumulative_cost,
                    incremental_time_hr=step_time,
                    cumulative_time_hr=cumulative_time,
                )
            )
            cumulative_cost -= step_cost
            cumulative_time -= step_time
            current_level = prev_level
            idx -= 1
        steps.reverse()
        return steps

    def _to_step(self, soc_kwh: float) -> int:
        step = self.inputs.soc_step_kwh
        return int(round(soc_kwh / step))

    def _from_step(self, level: int) -> float:
        return level * self.inputs.soc_step_kwh

    def _energy_to_steps(self, energy_kwh: float) -> int:
        step = self.inputs.soc_step_kwh
        return int(math.ceil(energy_kwh / step))

    @staticmethod
    def _improves(new_cost: float, new_time: float, old_cost: float, old_time: float) -> bool:
        if not math.isfinite(old_cost):
            return True
        if new_cost < old_cost - 1e-9:
            return True
        if abs(new_cost - old_cost) <= 1e-9 and new_time < old_time - 1e-9:
            return True
        return False


if __name__ == "__main__":
    def calculate_energy_consumption(
        distance_km: float,
        current_kmh: float,
        boat_speed_kmh: float = 18.0,
        base_consumption_per_km: float = 3.0,
    ) -> float:
        base_energy = distance_km * base_consumption_per_km
        multiplier = 1.25 if current_kmh < 0 else 0.75
        return base_energy * multiplier

    def build_segment_option(
        segment_name: str,
        distance_km: float,
        current_kmh: float,
        boat_speed_kmh: float = 18.0,
    ) -> SegmentOption:
        ground_speed = boat_speed_kmh + current_kmh
        if ground_speed <= 0:
            raise ValueError(
                f"Ground speed becomes non-positive for segment {segment_name}."
            )
        travel_time_hr = distance_km / ground_speed
        energy_kwh = calculate_energy_consumption(distance_km, current_kmh, boat_speed_kmh)
        return SegmentOption(
            label=segment_name,
            travel_time_hr=travel_time_hr,
            energy_kwh=energy_kwh,
        )

    def clock_string(hours: float) -> str:
        total_minutes = int(round(hours * 60))
        day = total_minutes // (24 * 60)
        minutes_into_day = total_minutes - day * 24 * 60
        hour = minutes_into_day // 60
        minute = minutes_into_day % 60
        prefix = f"Day {day} " if day else ""
        return f"{prefix}{hour:02d}:{minute:02d}"

    distances_km = {
        "A-B": 40.0,
        "B-C": 35.0,
        "C-D": 45.0,
        "D-E": 30.0,
    }
    currents_kmh = {
        "A-B": -2.5,
        "B-C": -1.8,
        "C-D": 3.2,
        "D-E": 2.0,
    }

    route = ["A", "B", "C", "D", "E"]
    boat_speed = 18.0
    segments: List[Segment] = []
    for start, end in zip(route[:-1], route[1:]):
        key = f"{start}-{end}"
        option = build_segment_option(
            segment_name=f"{start}->{end}",
            distance_km=distances_km[key],
            current_kmh=currents_kmh[key],
            boat_speed_kmh=boat_speed,
        )
        segments.append(
            Segment(start=start, end=end, options=[option])
        )

    stations = [
        Station(name="A", swap_cost=0.0, swap_time_hr=0.0, allow_swap=False, energy_cost_per_kwh=0.09),
        Station(
            name="B",
            swap_cost=45.0,
            swap_time_hr=0.30,
            queue_time_hr=0.25,
            operating_hours=(6.0, 22.0),
            available_batteries=3,
            energy_cost_per_kwh=0.09,  # Guangzhou: 0.64 RMB (~$0.09/kWh)
        ),
        Station(
            name="C",
            swap_cost=55.0,
            swap_time_hr=0.30,
            queue_time_hr=0.50,
            operating_hours=(0.0, 24.0),
            available_batteries=2,
            energy_cost_per_kwh=0.18,  # Hong Kong: 1.443 HKD (~$0.18/kWh)
        ),
        Station(
            name="D",
            swap_cost=40.0,
            swap_time_hr=0.30,
            queue_time_hr=0.17,
            operating_hours=(8.0, 20.0),
            available_batteries=4,
            energy_cost_per_kwh=0.09,  # Zhao Qing: 0.62-0.65 RMB (~$0.09/kWh)
        ),
        Station(name="E", swap_cost=0.0, swap_time_hr=0.0, allow_swap=False, energy_cost_per_kwh=0.09),
    ]

    battery_capacity = 300.0
    minimum_fraction = 0.20
    minimum_soc = battery_capacity * minimum_fraction

    inputs = FixedPathInputs(
        stations=stations,
        segments=segments,
        battery_capacity_kwh=battery_capacity,
        initial_soc_kwh=battery_capacity,
        final_soc_min_kwh=minimum_soc,
        min_soc_kwh=minimum_soc,
        energy_cost_per_kwh=0.12,
        time_cost_per_hr=25.0,
        soc_step_kwh=5.0,
        start_time_hr=6.0,
    )

    optimizer = FixedPathOptimizer(inputs)
    optimisation_result = optimizer.solve()

    print("Optimised schedule\n-------------------")
    for step in optimisation_result.steps:
        arrival_clock = clock_string(step.arrival_time_hr)
        departure_clock = clock_string(step.departure_time_hr)
        print(
            f"{step.station_name} @ {arrival_clock} -> {step.segment_label}"
            f" | swap={step.swap_taken}"
            f" | dwell={step.station_wait_time_hr + step.station_queue_time_hr + step.station_swap_time_hr:.2f}h"
            f" | travel={step.travel_time_hr:.2f}h"
            f" | SoC {step.soc_before_kwh:.1f}->{step.soc_after_segment_kwh:.1f} kWh"
            f" | incremental cost ${step.incremental_cost:.2f}"
        )

    print("\nTotals")
    print(f"  Total cost: ${optimisation_result.total_cost:.2f}")
    print(f"  Total travel time: {optimisation_result.total_time_hr:.2f} h")
    print(f"  Finish clock time: {clock_string(optimisation_result.finish_time_hr)}")
